# PS-Basic-course
Course material for the basic part of the four day PowerShell course.
