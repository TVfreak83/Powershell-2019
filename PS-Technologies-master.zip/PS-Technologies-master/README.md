# PS-Technologies

The course material on specific topics for the four day PowerShell course.